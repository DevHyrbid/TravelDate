//
//  ChatModels.swift
//  TravelDate
//
//  Pure data models for the API-only chat module.
//
//  CHANGED: ChatMediaKind.isVideo now (1) checks a backend type hint
//  first if one is ever provided, and (2) parses the URL properly via
//  URLComponents before reading the path extension, so a signed/CDN URL
//  like "https://server.com/video.mp4?token=123" is still detected as a
//  video — the old version ran pathExtension on the raw string including
//  the query string, which happened to work for that one example but not
//  for others where the query string itself contains a dot (e.g.
//  "...?ref=v1.2").
//

import Foundation
import UIKit

// MARK: - Room Type

enum ChatRoomType: String, Codable {
    case individual
    case group
    case match
}

// MARK: - Message Status (for optimistic UI)

enum MessageStatus {
    case sending   // shown immediately, waiting for API
    case sent      // API confirmed
    case failed    // API failed → allow retry
}

// MARK: - Chat User

struct ChatUser: Codable {
    let id: String?
    let name: String?
    let profileImage: String?

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case profileImage = "profile_image"
    }
}

// MARK: - Chat Message (server model)

struct ChatMessage: Codable {
    let id: String
    let roomId: String?
    let senderId: String?
    let content: String?
    let contentType: String?      // or Int if your API sends a number
    let messageType: Int?         // add if needed
    let createdAt: String?
    let sender: ChatUser?
    let fileUrl: String?
}

// MARK: - Chat Item (what the UI actually renders)
//
// We wrap the server message so we can also carry a local status
// (sending / sent / failed) and a temporary id for optimistic updates.

struct ChatItem {
    var id: String
    let senderId: String
    let senderName: String
    let senderImage: String?
    let profile_image: String?
    var content: String?          // make optional (image-only messages have no text)
    let createdAt: Date
    var status: MessageStatus
    var messageType: Int          // 1 = text, 2 = image, 3 = video
    var imageURL: String?
    var localImage: UIImage?
    // Video additions — same pattern as imageURL/localImage above.
    var videoURL: String?         // remote video URL (once uploaded/confirmed by server)
    var localVideoURL: URL?       // local file URL while the video is picked/uploading
    var videoThumbnail: UIImage?  // locally-generated thumbnail shown instantly (optimistic)
    var videoDuration: Int?       // seconds, filled in once known (local pick or server)
    var isMine: Bool {
        senderId == (User.curentUser?.id ?? "")
    }
}

extension ChatItem {

    init(message: ChatMessage) {
        self.id          = message.id
        self.senderId    = message.senderId ?? message.sender?.id ?? ""
        self.senderName  = message.sender?.name ?? ""
        self.senderImage = message.sender?.profileImage
        self.createdAt   = ChatDate.parse(message.createdAt)
        self.status      = .sent
        self.profile_image = message.sender?.profileImage ?? ""

        // ✅ Only signal is fileUrl — contentType/messageType are usually
        // nil on the current backend. We still pass contentType through
        // as a hint in case the backend starts sending it; ChatMediaKind
        // falls back to extension sniffing when it's absent.
        if let fileUrl = message.fileUrl, !fileUrl.isEmpty {
            if ChatMediaKind.isVideo(urlString: fileUrl, typeHint: message.contentType) {
                self.messageType = 3
                self.content     = nil
                self.imageURL    = nil
                self.videoURL    = fileUrl
            } else {
                self.messageType = 2
                self.content     = nil
                self.imageURL    = fileUrl   // direct full URL, no fallback needed
                self.videoURL    = nil
            }
        } else {
            self.messageType = 1
            self.content      = message.content ?? ""
            self.imageURL     = nil
            self.videoURL      = nil
        }
    }
    
    static func temporary(content: String, senderId: String) -> ChatItem {
        ChatItem(
            id:          "temp-\(UUID().uuidString)",
            senderId:    senderId,
            senderName:  "",
            senderImage: nil, profile_image: "",
            content:     content,
            createdAt:   Date(),
            status:      .sending,
            messageType: 1
        )
    }

    static func temporaryImage(localImage: UIImage, senderId: String) -> ChatItem {
        ChatItem(
            id:          "temp-\(UUID().uuidString)",
            senderId:    senderId,
            senderName:  "",
            senderImage: nil,profile_image: "",
            content:     nil,
            createdAt:   Date(),
            status:      .sending,
            messageType: 2,
            localImage:  localImage
        )
    }

    /// Same optimistic pattern as `temporaryImage`, for a locally-picked
    /// video. `thumbnail` should come from `ChatVideoThumbnailLoader`
    /// (generated from `localVideoURL`) so the bubble has something to
    /// show immediately, before upload finishes.
    static func temporaryVideo(localVideoURL: URL, thumbnail: UIImage?, duration: Int?, senderId: String) -> ChatItem {
        ChatItem(
            id:            "temp-\(UUID().uuidString)",
            senderId:      senderId,
            senderName:    "",
            senderImage:   nil,profile_image: "",
            content:       nil,
            createdAt:     Date(),
            status:        .sending,
            messageType:   3,
            localVideoURL: localVideoURL,
            videoThumbnail: thumbnail,
            videoDuration: duration
        )
    }
}

// MARK: - Media kind detection

/// Tells images and videos apart. Priority order:
///  1. A backend-supplied type hint (contentType/fileType), if present.
///  2. The URL's path extension — parsed via URLComponents so query
///     parameters (tokens, cache-busters, version strings) never affect
///     detection.
enum ChatMediaKind {
    private static let videoExtensions: Set<String> = ["mp4", "mov", "m4v", "avi", "webm", "3gp"]

    static func isVideo(urlString: String, typeHint: String? = nil) -> Bool {
        if let hint = typeHint?.lowercased(), !hint.isEmpty {
            if hint.contains("video") { return true }
            if hint.contains("image") { return false }
        }

        let path = URLComponents(string: urlString)?.path ?? urlString
        let ext = (path as NSString).pathExtension.lowercased()
        return videoExtensions.contains(ext)
    }
}

// MARK: - API Envelopes

struct CreateRoomResponse: Codable {
    let success: Bool?
    let code: Int?
    let message: String?
    let data: RoomData?
}

struct RoomData: Codable {
    let id: String?
    let type: String?
}

struct SendMessageResponse: Codable {
    let success: Bool?
    let code: Int?
    let message: String?
    let data: ChatMessage?
}

struct MessagesResponse: Codable {
    let success: Bool?
    let code: Int?
    let data: [ChatMessage]?
}
