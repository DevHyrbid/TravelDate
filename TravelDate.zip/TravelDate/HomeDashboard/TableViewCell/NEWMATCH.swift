
//  SavedGroupCell.swift
//  TravelDate

import UIKit

class SavedGroupCell: UITableViewCell {

    static let reuseId = "SavedGroupCell"

    // MARK: - UI
    let cardView      = UIView()
    let heroImage     = UIImageView()
    let badgeLabel    = PaddedLabel()
    let bookmarkBtn   = UIButton(type: .custom)
    let gradientLayer = CAGradientLayer()
    let nameLabel     = UILabel()
    let timeLabel     = UILabel()
    let locationLabel = UILabel()
    let viewGroupBtn  = UIButton(type: .system)
    let membersView   = MembersProgressView()
    private let travelersLabel = UILabel()

    var onViewGroup: (() -> Void)?
    var onBookmark:  (() -> Void)?

    // MARK: - Init
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
    }
    required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = heroImage.bounds
    }

    private func setup() {
        selectionStyle = .none
        backgroundColor = .clear
        contentView.backgroundColor = .clear

        // ── Card ──────────────────────────────────────────────────────────
        cardView.layer.cornerRadius = 22
        cardView.clipsToBounds      = true
        cardView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(cardView)

        // ── Hero fills entire card ────────────────────────────────────────
        heroImage.contentMode  = .scaleAspectFill
        heroImage.clipsToBounds = true
        heroImage.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(heroImage)

        // ── Gradient: starts mid-card, very dark at bottom 45%
        gradientLayer.colors = [
            UIColor.clear.cgColor,
            UIColor.black.cgColor
        ]

        gradientLayer.locations = [0.0, 1.0]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradientLayer.opacity = 0.8
        heroImage.layer.addSublayer(gradientLayer)

        // ── "New Strategy" badge — top-left ───────────────────────────────
        badgeLabel.text               = ""
        badgeLabel.font               = AppFont.medium(11)
        badgeLabel.textColor          = .white
        badgeLabel.backgroundColor    = UIColor(white: 0.18, alpha: 0.70)
        badgeLabel.layer.cornerRadius = 15
        badgeLabel.clipsToBounds      = true
        badgeLabel.textInsets         = UIEdgeInsets(top: 6, left: 14, bottom: 6, right: 14)
        badgeLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(badgeLabel)
        bookmarkBtn.removeFromSuperview()
        bookmarkBtn.removeFromSuperview()

            let bookmark = UIButton(type: .custom)
            bookmark.translatesAutoresizingMaskIntoConstraints = false

            bookmark.setBackgroundImage(
                UIImage(named: "imgBookmark"),
                for: .normal
            )

            bookmark.backgroundColor = .clear
            bookmark.adjustsImageWhenHighlighted = false
            bookmark.adjustsImageWhenDisabled = false

            bookmark.addTarget(
                self,
                action: #selector(bookmarkTapped),
                for: .touchUpInside
            )

            cardView.addSubview(bookmark)

            self.bookmarkBtn.removeFromSuperview()

        cardView.addSubview(bookmarkBtn)

        // ── Name label ────────────────────────────────────────────────────
        nameLabel.font          = AppFont.bold(20)
        nameLabel.textColor     = .white
        nameLabel.numberOfLines = 1
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(nameLabel)

        // ── Date row (vertical stack below name) ──────────────────────────
        let timeIcon = makeIcon("calendar")
        timeLabel.font      = AppFont.regular(12)
        timeLabel.textColor = UIColor(white: 0.88, alpha: 1)
        let timeRow = hStack([timeIcon, timeLabel], spacing: 8)
        timeRow.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(timeRow)

        // ── Location row ──────────────────────────────────────────────────
        let locIcon = makeIcon("mappin.and.ellipse")
        locationLabel.font      = AppFont.regular(14)
        locationLabel.textColor = UIColor(white: 0.88, alpha: 1)
        let locRow = hStack([locIcon, locationLabel], spacing: 8)
        locRow.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(locRow)

        // ── Members row: avatars LEFT, "N travelers" FAR RIGHT ───────────
        membersView.progressTrack.isHidden = true
        membersView.backgroundColor        = .clear
        membersView.translatesAutoresizingMaskIntoConstraints = false
        membersView.setContentHuggingPriority(.required, for: .horizontal)
        membersView.setContentCompressionResistancePriority(.required, for: .horizontal)

        travelersLabel.font          = AppFont.regular(14)
        travelersLabel.textColor     = UIColor(white: 0.88, alpha: 1)
        travelersLabel.textAlignment = .right
        travelersLabel.setContentHuggingPriority(.required, for: .horizontal)
        travelersLabel.translatesAutoresizingMaskIntoConstraints = false

        let spacer = UIView()
        spacer.translatesAutoresizingMaskIntoConstraints = false

        let membersRow = UIStackView(arrangedSubviews: [membersView, spacer, travelersLabel])
        membersRow.axis      = .horizontal
        membersRow.alignment = .center
        membersRow.spacing   = 0
        membersRow.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(membersRow)

        // ── "View Group" button ───────────────────────────────────────────
        // Screenshot: NOT full width — has 16pt margins each side, ~54pt tall
        viewGroupBtn.setTitle("View Group", for: .normal)
        viewGroupBtn.titleLabel?.font   = AppFont.semibold(15)
        viewGroupBtn.backgroundColor    = .themeOrange
        viewGroupBtn.setTitleColor(.white, for: .normal)
        viewGroupBtn.layer.cornerRadius = 27   // 54 / 2
        viewGroupBtn.translatesAutoresizingMaskIntoConstraints = false
        viewGroupBtn.addTarget(self, action: #selector(viewGroupTapped), for: .touchUpInside)
        cardView.addSubview(viewGroupBtn)

        // MARK: Constraints
        NSLayoutConstraint.activate([
            // Card
            cardView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 6),
            cardView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            cardView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            cardView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -6),

            // Hero = full card
            heroImage.topAnchor.constraint(equalTo: cardView.topAnchor),
            heroImage.leadingAnchor.constraint(equalTo: cardView.leadingAnchor),
            heroImage.trailingAnchor.constraint(equalTo: cardView.trailingAnchor),
            heroImage.bottomAnchor.constraint(equalTo: cardView.bottomAnchor),

            // Badge: 14pt from top-left
            badgeLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 14),
            badgeLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 14),

            // Bookmark: 12pt from top, 14pt from right — 40×40 WHITE circle
            bookmark.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 12),
                  bookmark.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -14),

                  bookmark.widthAnchor.constraint(equalToConstant: 40),
                  bookmark.heightAnchor.constraint(equalToConstant: 40),

            // View Group: 20pt from bottom, 16pt margins
            viewGroupBtn.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -20),
            viewGroupBtn.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -16),
            viewGroupBtn.heightAnchor.constraint(equalToConstant: 46),
            viewGroupBtn.widthAnchor.constraint(equalToConstant: 160),

            // Members row: 14pt above View Group
            membersRow.bottomAnchor.constraint(equalTo: viewGroupBtn.topAnchor, constant: -14),
            membersRow.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            membersRow.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -16),
            membersRow.heightAnchor.constraint(equalToConstant: 46),

            // Location: 10pt above members
            locRow.bottomAnchor.constraint(equalTo: membersRow.topAnchor, constant: -10),
            locRow.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),

            // Date: 8pt above location
            timeRow.bottomAnchor.constraint(equalTo: locRow.topAnchor, constant: -8),
            timeRow.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),

            // Name: 6pt above date
            nameLabel.bottomAnchor.constraint(equalTo: timeRow.topAnchor, constant: -6),
            nameLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            nameLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -60),
        ])
    }

    // MARK: - Configure
    func configure(with model: Group) {
        nameLabel.text      = model.title ?? ""
        locationLabel.text  = model.destination ?? ""
//        travelersLabel.text = "\(model.members?.count ?? 0) travelers"
        membersView.configure(
            members: model.members ?? [],
            totalCount: model.maxGroupSize ?? 0,
            completedCount: model.members?.count ?? 0
        )
    }

    func setImage(_ image: UIImage?)  { heroImage.image = image }
    func setTimeText(_ text: String)  { timeLabel.text  = text  }

    // MARK: - Helpers
    private func makeIcon(_ name: String) -> UIImageView {
        let iv = UIImageView(image: UIImage(systemName: name))
        iv.tintColor   = UIColor(white: 0.80, alpha: 1)
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.widthAnchor.constraint(equalToConstant: 16).isActive  = true
        iv.heightAnchor.constraint(equalToConstant: 16).isActive = true
        return iv
    }

    private func hStack(_ views: [UIView], spacing: CGFloat) -> UIStackView {
        let s = UIStackView(arrangedSubviews: views)
        s.axis = .horizontal; s.spacing = spacing; s.alignment = .center
        return s
    }

    @objc private func viewGroupTapped() { onViewGroup?() }
    @objc private func bookmarkTapped()  { onBookmark?()  }
}

// PaddedLabel.swift — shared utility (keep in one file)
class PaddedLabel: UILabel {
    var textInsets = UIEdgeInsets.zero
    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: textInsets))
    }
    override var intrinsicContentSize: CGSize {
        let s = super.intrinsicContentSize
        return CGSize(
            width:  s.width  + textInsets.left + textInsets.right,
            height: s.height + textInsets.top  + textInsets.bottom
        )
    }
}
